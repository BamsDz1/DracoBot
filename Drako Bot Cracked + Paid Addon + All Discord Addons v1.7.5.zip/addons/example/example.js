module.exports.run = async (client) => {
    client.on('ready', async (client) => {
        console.log("This is an example addon! You can delete it in addons/example")
    });
};